package kucheria_CSCI201_Assignment1;

import java.util.ArrayList;

public class Parent {
	private ArrayList<School> schools;
	
	

	public Parent() {
		schools = new ArrayList<School>();
	}
	
	public ArrayList<School> getSchools() {
		return schools;
	}
}
