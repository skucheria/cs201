package kucheria_CSCI201_Assignment1;

public class MeetingPeriods {
	private String day;
	public String getDay() {
		return day;
	}
	public Time getTime() {
		return time;
	}
	private Time time;
	public MeetingPeriods(String day, Time t) {
		this.day = day;
		time = t;
	}
}
