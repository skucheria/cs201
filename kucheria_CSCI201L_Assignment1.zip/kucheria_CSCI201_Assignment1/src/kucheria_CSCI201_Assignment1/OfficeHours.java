package kucheria_CSCI201_Assignment1;

public class OfficeHours {
	private String day;
	private Time time;

	
	public OfficeHours(String day, Time t) {
		this.day = day;
		time = t;
	}
	
	public String getDay() {
		return day;
	}
	public Time getTime() {
		return time;
	}
}
