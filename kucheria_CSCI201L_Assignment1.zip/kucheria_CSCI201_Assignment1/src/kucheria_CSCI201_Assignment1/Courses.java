package kucheria_CSCI201_Assignment1;

import java.util.ArrayList;

public class Courses {
	private int number;
	private String term;
	private int year;
	private ArrayList<Staff> staffMembers;
	private ArrayList<Meeting> meetings;

	
	public Courses(int num, String term, int year, ArrayList<Staff> membs) {
		this.number = num;
		this.term = term;
		this.year = year;
		staffMembers = membs;
	}
	
	public int getNum() {
		return number;
	}
	public String getTerm() {
		return term;
	}
	public int getYear() {
		return year;
	}
	public ArrayList<Staff> getStaff() {
		return staffMembers;
	}
	
	public ArrayList<Meeting> getMeetings() {
		return meetings;
	}

}
