package kucheria_CSCI201_Assignment1;

public class Name {
	private String fname;
	private String lname;

	public String getFname() {
		return fname;
	}
	public String getLname() {
		return lname;
	}
	
	

}
