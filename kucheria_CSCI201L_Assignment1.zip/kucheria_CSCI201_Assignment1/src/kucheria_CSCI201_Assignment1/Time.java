package kucheria_CSCI201_Assignment1;

public class Time {
	private String start;
	public String getStart() {
		return start;
	}

	public String getEnd() {
		return end;
	}

	private String end;
	
	public Time(String start, String end) {
		this.start = start;
		this.end = end;
	}
}

