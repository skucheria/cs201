package kucheria_CSCI201_Assignment1;

import java.util.ArrayList;

public class Meeting {
	private String type;
	private String section;
	private String room;
	private ArrayList<MeetingPeriods> meetingPeriods;
	private ArrayList<Assistant> assistants;
	
	public Meeting(String type, String section, String room, ArrayList<MeetingPeriods> periods, ArrayList<Assistant> ass) {
		this.type = type;
		this.section = section;
		this.room = room;
		this.meetingPeriods = periods;
		this.assistants = ass;
	}
	
	public String getType() {
		return type;
	}
	public String getSection() {
		return section;
	}
	public String getRoom() {
		return room;
	}
	public ArrayList<MeetingPeriods> getPeriods() {
		return meetingPeriods;
	}
	public ArrayList<Assistant> getAss() {
		return assistants;
	}
	
}
