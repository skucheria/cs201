package kucheria_CSCI201_Assignment1;

public class Assistant {
	public int getStaffMemberID() {
		return staffMemberID;
	}

	private int staffMemberID;
	
	
}
