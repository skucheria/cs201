package kucheria_CSCI201_Assignment1;

import java.util.ArrayList;

public class Department {
	private String longName;
	private String prefix;
	private ArrayList<Courses> courses;

	public Department(String lName, String pref, ArrayList<Courses> crs) {
		longName = lName;
		prefix = pref;
		courses = crs;
	}
	
	public String getLong() {
		return longName;
	}
	public String getPref() {
		return prefix;
	}
	public ArrayList<Courses> getCourses() {
		return courses;
	}
	
}
