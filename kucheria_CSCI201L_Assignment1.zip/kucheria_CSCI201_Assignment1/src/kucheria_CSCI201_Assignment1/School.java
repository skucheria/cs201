package kucheria_CSCI201_Assignment1;

import java.util.ArrayList;

public class School {
	public String getName() {
		return name;
	}
	
	private String name;
	private ArrayList<Department> departments;
	
	
	public ArrayList<Department> getDepartments() {
		return departments;
	}



	public School() {
        this.departments = new ArrayList<Department>();
	}
	
	
	
}
