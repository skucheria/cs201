package kucheria_CSCI201_Assignment1;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import com.google.gson.Gson;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
import com.google.gson.stream.MalformedJsonException;
import java.io.FileNotFoundException;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class New {
	public static void main(String []args) {
		Gson gson = new Gson();
		Scanner scan = new Scanner(System.in);
		String filename = " ";
		
		Boolean quit = false;
		Boolean readIn = false;
		Parent allData = new Parent();
		
		while(readIn == false) {
			System.out.println("What is the name of the input file? ");
			filename = scan.nextLine();
			try {
				BufferedReader br = new BufferedReader( new FileReader(filename));	
				allData = gson.fromJson(br, Parent.class);
				readIn = true;
				System.out.println("");
			}
			catch(JsonSyntaxException ex) {
				System.out.println("That file is not a well-formed JSON file.");
				System.out.println("");
			}
			catch(JsonIOException e) {
				System.out.println("That file is not a well-formed JSON file.");
				System.out.println("");
			}
			catch (FileNotFoundException fnfe){
				System.out.println("The file could not be found.");
				System.out.println("");
			}
			
		}
		
//		try {
			ArrayList<School> allSchools = allData.getSchools();
			while(quit!=true) { //main menu loop
				int response = -1;
				System.out.println("   1) Display schools" );
				System.out.println("   2) Exit" );
				System.out.print("What would you like to do? ");
				try {
					response = scan.nextInt();
				}
				catch(InputMismatchException miss) {
					scan.nextLine();
				}
				
				if(response<1 || response>2) {
					System.out.println("");
					System.out.println("That is not a valid option.");
					System.out.println("");
				}
				else if(response == 2) {
					System.out.println("");
					System.out.println("Thank you for using my program.");	
					quit = true;
					break;
				}
				else {
					while(quit!=true) { //Schools menu
						System.out.println("");
						System.out.println("Schools");
						for(int x=0; x<allSchools.size(); x++) {
							int count = x+1;
							System.out.println("   " + count + ") " + allSchools.get(x).getName());
						}
						int count = allSchools.size()+1;
						System.out.println("   " + count + ") Go to main menu");
						count++;
						System.out.println("   " + count + ") Exit");
						System.out.print("What would you like to do? ");
						try {
							response = scan.nextInt();
						}
						catch(InputMismatchException miss) {
							scan.nextLine();
							System.out.println("");
							System.out.println("That is not a valid option.");
							System.out.println("");
							continue;		
						}
						//response = scan.nextInt();
						if(response<1 || response>count) {
							System.out.println("");
							System.out.println("That is not a valid option.");
							System.out.println("");
						}
						else if(response == count) {
							System.out.println("");
							System.out.println("Thank you for using my program.");	
							quit = true;
						}
						else if(response == (count-1)) {
							break;
						}
						else { 
							while(quit!=true) { //departments menu
								int schoolIndex = response-1;
								int resp = 0;
								ArrayList<Department> departments = allSchools.get(schoolIndex).getDepartments();
								System.out.println("");
								System.out.println("Departments");
								for(int x=0; x<departments.size(); x++) {
									count = x+1;
									String lName =  departments.get(x).getLong();
									String prefix =  departments.get(x).getPref();
									System.out.println("   " + count + ") " + lName + " (" + prefix + ")" );
								}
								count = departments.size()+1;
								System.out.println("   " + count + ") Go to Schools menu");
								count++;
								System.out.println("   " + count + ") Exit");
								System.out.print("What would you like to do? ");
								try {
									resp = scan.nextInt();
								}
								catch(InputMismatchException miss) {
									scan.nextLine();
									System.out.println("");
									System.out.println("That is not a valid option.");
									System.out.println("");
									continue;		
								}
								if(resp<1 || resp>count) {
									System.out.println("");
									System.out.println("That is not a valid option.");
									System.out.println("");
								}
								else if(resp == count) {
									System.out.println("");
									System.out.println("Thank you for using my program.");	
									quit = true;
								}
								else if(resp == (count-1)) {
									break;
								}
								else {
									while(quit!=true) { //courses menu
										System.out.println("");
										int departIndex = resp-1;
										int resp2 = -1;
										ArrayList<Courses> courses = departments.get(departIndex).getCourses();
										System.out.println(departments.get(departIndex).getPref() + " Courses");
										for(int x=0; x<courses.size(); x++) {
											count = x+1;
											int number = courses.get(x).getNum();
											String term = courses.get(x).getTerm();
											int year = courses.get(x).getYear();
											System.out.println("   " + count + ") " + departments.get(departIndex).getPref() + " " + number + " " + term + " " + year);
										}
										count = courses.size()+1;
										System.out.println("   " + count + ") Go to Departments menu");
										count++;
										System.out.println("   " + count + ") Exit");
										System.out.print("What would you like to do? ");
										
										try {
											resp2 = scan.nextInt();
										}
										catch(InputMismatchException miss) {
											scan.nextLine();
											System.out.println("");
											System.out.println("That is not a valid option.");
											System.out.println("");
											continue;		
										}

										if(resp2<1 || resp2>count) {
											System.out.println("");
											System.out.println("That is not a valid option.");
											System.out.println("");
										}
										else if(resp2 == count) {
											System.out.println("");
											System.out.println("Thank you for using my program.");	
											quit = true;
										}
										else if(resp2 == (count-1)) {
											break;
										}
										else {
											while(quit!=true) { //specific course menu
												System.out.println("");
												int courseIndex = resp2-1;
												int resp3 = -1;
												ArrayList<Staff> staff = courses.get(courseIndex).getStaff();
												ArrayList<Staff> instructors = new ArrayList<Staff>();
												ArrayList<Staff> tas = new ArrayList<Staff>();
												ArrayList<Staff> cps = new ArrayList<Staff>();
												ArrayList<Staff> graders = new ArrayList<Staff>();
												int number = courses.get(courseIndex).getNum();
												String term = courses.get(courseIndex).getTerm();
												int year = courses.get(courseIndex).getYear();
												System.out.println(departments.get(departIndex).getPref() + " " + number + " " + term + " " + year);
												System.out.println("   1) View course staff" );
												System.out.println("   2) View meeting information" );
												System.out.println("   3) Go to " + departments.get(departIndex).getPref() + " Courses menu" );
												System.out.println("   4) Exit" );
												System.out.print("What would you like to do? ");
												try {
													resp3 = scan.nextInt();
												}
												catch(InputMismatchException miss) {
													scan.nextLine();
													System.out.println("");
													System.out.println("That is not a valid option.");
													System.out.println("");
													continue;		
												}
												if(resp3 == 4) {
													System.out.println("");
													System.out.println("Thank you for using my program.");	
													quit = true;
												}
												else if(resp3 == 3) {
													break;
												}
												else if(resp3<1 || resp3>4) {
													System.out.println("");
													System.out.println("That is not a valid option.");
													System.out.println("");
												}
												else if(resp3 == 2) { //meeting information menu
													ArrayList<Meeting> meetings = courses.get(courseIndex).getMeetings();
													ArrayList<Meeting> lectures = new ArrayList<Meeting>();
													ArrayList<Meeting> labs = new ArrayList<Meeting>();
													ArrayList<Meeting> quizzes = new ArrayList<Meeting>();
													for(int x=0; x<meetings.size(); x++) {
														String type = meetings.get(x).getType();
														if(type.equals("lecture")) {
															//System.out.println("Adding a lecture");
															lectures.add(meetings.get(x));
														}
														else if(type.equals("lab")) {
															//System.out.println("Adding a lab");

															labs.add(meetings.get(x));
														}
														else if(type.equals("quiz")) {
															//System.out.println("Adding a quiz");

															quizzes.add(meetings.get(x));
														}
														else {
															//type is null/not lec/lab/quiz do nothing
														}
													}
													while(quit!=true) { //meeting menu
														System.out.println("");
														System.out.println(departments.get(departIndex).getPref() + " " + number + " " + term + " " + year);
														System.out.println("Meeting Information");
														System.out.println("   1) Lecture" );
														System.out.println("   2) Lab" );
														System.out.println("   3) Quiz" );
														System.out.println("   4) Go to " + departments.get(departIndex).getPref() + " " + number + " " + term + " " + year + " menu" );
														System.out.println("   5) Exit" );
														System.out.print("What would you like to do? ");
														int resp4 = -1;
														try {
															resp4 = scan.nextInt();
														}
														catch(InputMismatchException miss) {
															scan.nextLine();
															System.out.println("");
															System.out.println("That is not a valid option.");
															System.out.println("");
															continue;		
														}
														if(resp4 == 1) { //lecture info view
															System.out.println("");
															if(lectures.size()>0) { //there are lecture sections
																System.out.println(departments.get(departIndex).getPref() + " " + number + " " + term + " " + year);
																System.out.println("Lecture Meeting Information");
																for(int x=0; x<lectures.size(); x++) {
																	String section = lectures.get(x).getSection();
																	String room = lectures.get(x).getRoom();
																	if(section == null) {
																		section = "None";
																	}
																	if(room == null) {
																		room = "None";
																	}
																	System.out.println("Section: " + section);
																	System.out.println("Room: " + room);
																	ArrayList<MeetingPeriods> periods = lectures.get(x).getPeriods();
																	ArrayList<Assistant> assistants = lectures.get(x).getAss(); //FINISH ASSISTANTS FOR LECTURES
																	
																	System.out.print("Meetings: ");
																	for(int y=0; y<periods.size(); y++) {
																		String day = periods.get(y).getDay();
																		String start = periods.get(y).getTime().getStart();
																		String end = periods.get(y).getTime().getEnd();
																		if(day == null) {
																			day = "Unknown";
																		}
																		if(start == null) {
																			start = "Unknown";
																		}
																		if(end == null) {
																			end = "Unknown";
																		}
																		if(y>0) { //need comma
																			System.out.print(", ");
																		}
																		System.out.print(day + " " + start + "-" + end );
																		
																	}
																	System.out.println("");
																	System.out.print("Assistants: ");
																	if(assistants == null) {
																		System.out.print("None");
																	}
																	else {
																		for(int y=0; y<assistants.size(); y++) {
																			if(y>0) {
																				System.out.print(", ");
																			}
																			int id = assistants.get(y).getStaffMemberID();
																			for(int z=0; z<staff.size(); z++) {
																				if(id == staff.get(z).getId()) {
																					Name myN = staff.get(z).getName();
																					System.out.print(myN.getFname() + " " + myN.getLname());
																				}
																			}
																		}
																	}
																}
																System.out.println("");
																System.out.println("");
															}
															else { //no lectures
																System.out.println("");
															}
														}
														else if(resp4 == 2) { //lab info view
															System.out.println("");
															if(labs.size()>0) { //there are lab sections
																System.out.println(departments.get(departIndex).getPref() + " " + number + " " + term + " " + year);
																System.out.println("Lab Meeting Information");
																for(int x=0; x<labs.size(); x++) {
																	String section = labs.get(x).getSection();
																	String room = labs.get(x).getRoom();
																	if(section == null) {
																		section = "None";
																	}
																	if(room == null) {
																		room = "None";
																	}
																	System.out.println("Section: " + section);
																	System.out.println("Room: " + room);
																	ArrayList<MeetingPeriods> periods = labs.get(x).getPeriods();
																	ArrayList<Assistant> assistants = labs.get(x).getAss(); //FINISH ASSISTANTS FOR LABS
																	ArrayList<Assistant> finalAss = new ArrayList<Assistant>(); 
																	System.out.print("Meetings: ");
																	for(int y=0; y<periods.size(); y++) {
																		String day = periods.get(y).getDay();
																		String start = periods.get(y).getTime().getStart();
																		String end = periods.get(y).getTime().getEnd();
																		if(day == null) {
																			day = "Unknown";
																		}
																		if(start == null) {
																			start = "Unknown";
																		}
																		if(end == null) {
																			end = "Unknown";
																		}
																		if(y>0) { //need comma
																			System.out.print(", ");
																		}
																		System.out.print(day + " " + start + "-" + end );
																	}
																	System.out.println("");
																	System.out.print("Assistants: ");
																	if(assistants == null) {
																		System.out.print("None");
																	}
																	else {
																		for(int y=0; y<assistants.size(); y++) {
																			if(y>0) {
																				System.out.print(", ");
																			}
																			int id = assistants.get(y).getStaffMemberID();
																			for(int z=0; z<staff.size(); z++) {
																				if(id == staff.get(z).getId()) {
																					Name myN = staff.get(z).getName();
																					System.out.print(myN.getFname() + " " + myN.getLname());
																				}
																			}
																		}
																	}
																}
																System.out.println("");
																System.out.println("");
															}
															else { //no labs
																System.out.println("");
															}
														}
														else if(resp4 == 3) { //quiz info view 
															System.out.println("");

															if(quizzes.size()>0) { //at least one quiz section
																System.out.println(departments.get(departIndex).getPref() + " " + number + " " + term + " " + year);
																System.out.println("Quiz Meeting Information");
																for(int x=0; x<quizzes.size(); x++) {
																	String section = quizzes.get(x).getSection();
																	String room = quizzes.get(x).getRoom();
																	if(section == null) {
																		section = "None";
																	}
																	if(room == null) {
																		room = "None";
																	}
																	System.out.println("Section: " + section);
																	System.out.println("Room: " + room);
																	ArrayList<MeetingPeriods> periods = quizzes.get(x).getPeriods();
																	ArrayList<Assistant> assistants = quizzes.get(x).getAss(); //FINISH ASSISTANTS FOR QUIZ
																	System.out.print("Meetings: ");
																	for(int y=0; y<periods.size(); y++) {
																		String day = periods.get(y).getDay();
																		String start = periods.get(y).getTime().getStart();
																		String end = periods.get(y).getTime().getEnd();
																		if(day == null) {
																			day = "Unknown";
																		}
																		if(start == null) {
																			start = "Unknown";
																		}
																		if(end == null) {
																			end = "Unknown";
																		}
																		if(y>0) { //need comma
																			System.out.print(", ");
																		}
																		System.out.print(day + " " + start + "-" + end );
																	}
																	System.out.println("");
																	System.out.print("Assistants: ");
																	if(assistants == null) {
																		System.out.print("None");
																	}
																	else {
																		for(int y=0; y<assistants.size(); y++) {
																			if(y>0) {
																				System.out.print(", ");
																			}
																			int id = assistants.get(y).getStaffMemberID();
																			for(int z=0; z<staff.size(); z++) {
																				if(id == staff.get(z).getId()) {
																					Name myN = staff.get(z).getName();
																					System.out.print(myN.getFname() + " " + myN.getLname());
																				}
																			}
																		}
																	}
																}
																System.out.println("");
																System.out.println("");
															}
															else { //no quiz sections
																System.out.println("");
															}
														}
														else if(resp4 == 4) { //go to previous menu
															break;
														}
														else if(resp4 == 5) { //quit
															System.out.println("");
															System.out.println("Thank you for using my program.");	
															quit = true;
														}
														else if(resp4<1 || resp4>5) { //not valid
															System.out.println("");
															System.out.println("That is not a valid option.");
															System.out.println("");
														}
													}
												}
												else if(resp3 == 1) {//course staff menu
													/*
													ArrayList<Staff> staff = courses.get(courseIndex).getStaff();
													ArrayList<Staff> instructors = new ArrayList<Staff>();
													ArrayList<Staff> tas = new ArrayList<Staff>();
													ArrayList<Staff> cps = new ArrayList<Staff>();
													ArrayList<Staff> graders = new ArrayList<Staff>();
													*/
													for(int x=0; x<staff.size(); x++) {
														String type = staff.get(x).getType();
														if(type.equals("instructor")) {
															instructors.add(staff.get(x));
														}
														else if(type.equals("ta")) {
															tas.add(staff.get(x));
														}
														else if(type.equals("cp")) {
															cps.add(staff.get(x));
														}
														else if(type.equals("grader")) {
															graders.add(staff.get(x));
														}
														
													}
													while(quit!=true) { //course staff menu
														System.out.println(departments.get(departIndex).getPref() + " " + number + " " + term + " " + year);
														System.out.println("Course Staff");
														System.out.println("   1) View Instructors" );
														System.out.println("   2) View TA's" );
														System.out.println("   3) View CP's" );
														System.out.println("   4) View Graders" );
														System.out.println("   5) Go to " + departments.get(departIndex).getPref() + " " + number + " " + term + " " + year + " menu" );
														System.out.println("   6) Exit" );
														System.out.print("What would you like to do? ");
														int resp5 = -1;
														try {
															resp5 = scan.nextInt();
														}
														catch(InputMismatchException miss) {
															scan.nextLine();
															System.out.println("");
															System.out.println("That is not a valid option.");
															System.out.println("");
															continue;		
														}
														if(resp5 == 1) { //listing instructors
															if(instructors.size()>0) {
																System.out.println("");
																System.out.println(departments.get(departIndex).getPref() + " " + number + " " + term + " " + year);
																System.out.println("Instructor(s)");
																for(int x=0; x<instructors.size(); x++) {
																	int id = instructors.get(x).getId();
																	Name full = instructors.get(x).getName();
																	String first = full.getFname();
																	String last = full.getLname();
																	String email = instructors.get(x).getEmail();
																	String phone = instructors.get(x).getPhone();
																	String office = instructors.get(x).getOffice();
																	String image = instructors.get(x).getImage();
																	ArrayList<OfficeHours> hours = instructors.get(x).getOH();
																	if(first == null) {
																		first = " ";
																	}
																	if(last == null) {
																		last = " ";
																	}
																	if(email == null) {
																		email = "Unknown";
																	}
																	if(phone == null) {
																		phone = "Unknown";
																	}
																	if(office == null) {
																		office = "Unknown";
																	}
																	if(image == null) {
																		image = "Unknown";
																	}
																	System.out.println("Name: " + first + " " + last);
																	System.out.println("Email: "+ email);
																	System.out.println("Image: " + image);
																	System.out.println("Phone: " + phone);
																	System.out.println("Office: " + office);
																	System.out.print("Office Hours: ");
																	for(int y=0; y<hours.size(); y++) {
																		String day = hours.get(y).getDay();
																		Time t = hours.get(y).getTime();
																		String st;
																		String ed;
																		if(t == null) {
																			st = "NA";
																			ed = "NA";
																		}
																		else {
																			st = t.getStart();
																			ed = t.getEnd();
																		}
																		if(day == null) {
																			day = "NA";
																		}
																		if(st == null) {
																			st = " ";
																		}
																		if(ed == null) {
																			ed = " ";
																		}
																		if(y>0) {
																			System.out.print(", ");
																		}
																		System.out.print(day + " " + st + "-" + ed);
																	}
																	System.out.println("");
																	System.out.println("");

																}
																System.out.println("");
																System.out.println("");

															}
															else {
																System.out.println("No instructors for this course");
																System.out.println("");
															}
														}
														else if(resp5 == 2) { //listing ta's
															System.out.println("");

															if(tas.size()>0) {
																System.out.println(departments.get(departIndex).getPref() + " " + number + " " + term + " " + year);
																System.out.println("TA(s)");
																for(int x=0; x<tas.size(); x++) {
																	int id = tas.get(x).getId();
																	Name full = tas.get(x).getName();
																	String first = full.getFname();
																	String last = full.getLname();
																	String email = tas.get(x).getEmail();
																	String phone = tas.get(x).getPhone();
																	String office = tas.get(x).getOffice();
																	String image = tas.get(x).getImage();
																	ArrayList<OfficeHours> hours = tas.get(x).getOH();
																	System.out.println(first + " " + last + " email is " + email);
																	if(first == null) {
																		first = " ";
																	}
																	if(last == null) {
																		last = " ";
																	}
																	if(email == null) {
																		email = " ";
																	}
																	if(phone == null) {
																		phone = "Unknown";
																	}
																	if(office == null) {
																		office = "Unknown";
																	}
																	if(image == null) {
																		image = "Unknown";
																	}
																	System.out.println("Name: " + first + " " + last);
																	System.out.println("Email: "+ email);
																	System.out.println("Image: " + image);
																	System.out.println("Phone: " + phone);
																	System.out.println("Office: " + office);
																	System.out.print("Office Hours: ");
																	for(int y=0; y<hours.size(); y++) {
																		String day = hours.get(y).getDay();
																		Time t = hours.get(y).getTime();
																		String st;
																		String ed;
																		if(t == null) {
																			st = "NA";
																			ed = "NA";
																		}
																		else {
																			st = t.getStart();
																			ed = t.getEnd();
																		}
																		if(day == null) {
																			day = " ";
																		}
																		if(st == null) {
																			st = " ";
																		}
																		if(ed == null) {
																			ed = " ";
																		}
																		if(y>0) {
																			System.out.print(", ");
																		}
																		System.out.print(day + " " + st + "-" + ed);
																	}
																}
																System.out.println("");
																System.out.println("");
															}
															else {
																System.out.println("No TA's for this course");
																System.out.println("");
															}
														}
														else if(resp5 == 3) { //listing cp's
															System.out.println("");
															if(cps.size()>0) {
																System.out.println(departments.get(departIndex).getPref() + " " + number + " " + term + " " + year);
																System.out.println("CP(s)");
																for(int x=0; x<cps.size(); x++) {
																	int id = cps.get(x).getId();
																	Name full = cps.get(x).getName();
																	String first = full.getFname();
																	String last = full.getLname();
																	String email = cps.get(x).getEmail();
																	String phone = cps.get(x).getPhone();
																	String office = cps.get(x).getOffice();
																	String image = cps.get(x).getImage();
																	ArrayList<OfficeHours> hours = cps.get(x).getOH();
																	if(first == null) {
																		first = " ";
																	}
																	if(last == null) {
																		last = " ";
																	}
																	if(email == null) {
																		email = " ";
																	}
																	if(phone == null) {
																		phone = "Unknown";
																	}
																	if(office == null) {
																		office = "Unknown";
																	}
																	if(image == null) {
																		image = "Unknown";
																	}
																	System.out.println("Name: " + first + " " + last);
																	System.out.println("Email: "+ email);
																	System.out.println("Image: " + image);
																	System.out.println("Phone: " + phone);
																	System.out.println("Office: " + office);
																	System.out.print("Office Hours: ");
																	for(int y=0; y<hours.size(); y++) {
																		String day = hours.get(y).getDay();
																		Time t = hours.get(y).getTime();
																		String st;
																		String ed;
																		if(t == null) {
																			st = "NA";
																			ed = "NA";
																		}
																		else {
																			st = t.getStart();
																			ed = t.getEnd();
																		}
																		if(day == null) {
																			day = " ";
																		}
																		if(st == null) {
																			st = " ";
																		}
																		if(ed == null) {
																			ed = " ";
																		}
																		if(y>0) {
																			System.out.print(", ");
																		}
																		System.out.print(day + " " + st + "-" + ed);
																	}
																}
																System.out.println("");
																System.out.println("");
															}
															else {
																System.out.println("No CP's for this course");
																System.out.println("");
															}
														}
														else if(resp5 == 4) { //listing graders
															if(graders.size()>0) {
																System.out.println(departments.get(departIndex).getPref() + " " + number + " " + term + " " + year);
																System.out.println("Grader(s)");
																for(int x=0; x<graders.size(); x++) {
																	int id = graders.get(x).getId();
																	Name full = graders.get(x).getName();
																	String first = full.getFname();
																	String last = full.getLname();
																	String email = graders.get(x).getEmail();
																	String phone = graders.get(x).getPhone();
																	String office = graders.get(x).getOffice();
																	String image = graders.get(x).getImage();
																	ArrayList<OfficeHours> hours = graders.get(x).getOH();
																	if(first == null) {
																		first = " ";
																	}
																	if(last == null) {
																		last = " ";
																	}
																	if(email == null) {
																		email = " ";
																	}
																	if(phone == null) {
																		phone = "Unknown";
																	}
																	if(office == null) {
																		office = "Unknown";
																	}
																	if(image == null) {
																		image = "Unknown";
																	}
																	System.out.println("Name: " + first + " " + last);
																	System.out.println("Email: "+ email);
																	System.out.println("Image: " + image);
																	System.out.println("Phone: " + phone);
																	System.out.println("Office: " + office);
																	System.out.print("Office Hours: ");
																	for(int y=0; y<hours.size(); y++) {
																		String day = hours.get(y).getDay();
																		Time t = hours.get(y).getTime();
																		String st;
																		String ed;
																		if(t == null) {
																			st = "NA";
																			ed = "NA";
																		}
																		else {
																			st = t.getStart();
																			ed = t.getEnd();
																		}
																		
																		if(day == null) {
																			day = " ";
																		}
																		if(st == null) {
																			st = " ";
																		}
																		if(ed == null) {
																			ed = " ";
																		}
																		if(y>0) {
																			System.out.print(", ");
																		}
																		System.out.print(day + " " + st + "-" + ed);
																	}
																}
																System.out.println("");
																System.out.println("");
															}
															else {
																System.out.println("No graders for this course");
																System.out.println("");
															}
														}
														else if(resp5 == 5) { //go to previous menu
															break;
														}
														else if(resp5 == 6) { //quit
															System.out.println("");
															System.out.println("Thank you for using my program.");	
															quit = true;
														}
														else if(resp5<1 || resp5>6) { //not valid
															System.out.println("");
															System.out.println("That is not a valid option.");
															System.out.println("");
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			} //end of main while loop
//		} //end of try 
//		catch (IOException ioe){
//			System.out.println("IOException: " + ioe.getMessage());
//		}		
	}
}
