package kucheria_CSCI201L_Assignment4;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;
import java.util.Vector;

public class BlackJackServer {
	//initializing private data members: map of games and list of all players
	private Map<String, BlackJackRoom> games;
	private Vector<PlayerThread> playerThreads; 
	
	public BlackJackServer(int port) throws IOException{
		ServerSocket ss = new ServerSocket(port);  
		System.out.println("Successfully started the Black Jack server on port " + port);
		games = new HashMap<String, BlackJackRoom>();
		playerThreads = new Vector<PlayerThread>();
		while(true) {
			Socket s = ss.accept(); //socket has an input and output streams
			PlayerThread pt = new PlayerThread(s, this);
			playerThreads.add(pt);
		}	
	}
	
	public static void main(String[]args) {
		Boolean validPort = false;
		Scanner scan = new Scanner(System.in);
		String port = " ";
		System.out.println("Welcome to the Black Jack Server");
		while(!validPort) { //keep looping until a valid port number has been entered
			System.out.println("Please enter a port number");
			port = scan.nextLine();
			try {
				BlackJackServer cr = new BlackJackServer(Integer.valueOf(port));
				validPort = true; //if no exceptions thrown, loop will end here 
			}
			catch(InputMismatchException ime) {
				System.out.println("Invalid port number.");
			}
			catch(IOException ioe) {
				System.out.println("Invalid port number.");
			}
			catch(IllegalArgumentException iae) {
				System.out.println("Invalid port number.");
			}
			
		}
	}
	
	//function to send the starting message to all players in the game by taking the game name as a parameter
	public void broadcast(String gamename) {
		BlackJackRoom room = games.get(gamename);
		ArrayList<PlayerThread> players = room.getPlayers();
		for(PlayerThread player : players) {
			try {
				player.getOos().writeObject(new GameMessage("serv", "Let the game commence. Good luck to all players!", 3));
				player.getOos().flush();
			}
			catch(IOException ioe) {
				System.out.println("Exception: " +ioe.getMessage());
			}
		}
	}
	
	//checks to see if the username parameter is already used in the game that corresponds to the gamename parameter
	public Boolean currentUser(String gamename, String username) {
		BlackJackRoom room = games.get(gamename);
		if(room != null) {
			ArrayList<PlayerThread> players = room.getPlayers();
			for(PlayerThread player : players) {
				if(player.getUsername().equals(username)) {
					return true;
				}
			}
		}
		return false;
	}
	
	//check to see if the game room that corresponds to the string name is full or not when someone is trying to joint it. 
	public Boolean isRoomFull(String name) {
		BlackJackRoom room = games.get(name);
		if(room != null) {
			if(room.getNumPlayers() - room.getPlayers().size() == 0) {
				return true;
			}
			else {
				return false;
			}
		}
		else 
			return false;
	}
	//check to see if a game with the name parameter already exists
	public Boolean roomExists(String name) {
		BlackJackRoom exists = games.get(name);
		if(exists==null) {
			return false;
		}
		return true;
	}
	//return the BlackJackRoom object of the game that corresponds to the name parameter
	public BlackJackRoom getGame(String name) {
		return games.get(name);
	}
	//adds a player to the game that correponds to the name parameter
	public void joinGame(String name, PlayerThread player) {
		BlackJackRoom room = games.get(name);
		room.addPlayer(player);
	}
	//creates a game based off of the game name, number of players, and the player who created the game
	public void createGame(String name, int players, PlayerThread player) {
		BlackJackRoom room = new BlackJackRoom(players, name);
		room.addPlayer(player);
		games.put(name, room);
	}
}
