package kucheria_CSCI201L_Assignment4;
import java.util.ArrayList;
import Game_Tools.Card;
import Game_Tools.Deck;

public class BlackJackRoom {
	//creating all private variables
	private int numPlayers;
	private String gameName;
	private ArrayList<PlayerThread> players;
	private Boolean over = false;
	private Deck deck;
	private ArrayList<Card> dealerHand;
	//calling the shuffle method from the deck class
	public void shuffle() {
		deck.shuffle();
	}
	//getting the new, full deck for a new round of gameplay
	public void getNewDeck() {
		deck = new Deck();
	}
	//clears the hands of players after one round and prepares for next round of gameplay
	public void clearAllHands() {
		for(PlayerThread player : players) {
			player.getHand().clear();
		}
		dealerHand.clear();
	}
	//return the dealers hand 
	public ArrayList<Card> getDealerHand(){
		return dealerHand;
	}
	//function to deal a card to just one player, the one in the parameter
	public void dealSinglePlayer(PlayerThread player) {
		player.getHand().add(deck.deal());
	}
	//deal a card for the dealer by putting it in the dealer hand
	public void dealForDealer() {
		dealerHand.add(deck.deal());
	}
	//this is the initial deal function that deals to all players at the start of the game. 
	public void deal() {
		for(int x=0; x<=numPlayers; x++) {
			if(x!=numPlayers) { //deal for players
				players.get(x).getHand().add(deck.deal());
			}
			else { //deal for dealer
				dealerHand.add(deck.deal());
			}
		}
	}
	//constructor where number of players, game name, deck, players, and dealer are all initialized
	public BlackJackRoom(int num, String name) {
		numPlayers = num;
		gameName = name;
		players = new ArrayList<PlayerThread>();
		deck = new Deck();
		dealerHand = new ArrayList<Card>();
	}
	//adds a player to the to game room arraylist of players
	public void addPlayer(PlayerThread player) {
		players.add(player);
	}
	// returns an arraylist of all the players in the game room
	public ArrayList<PlayerThread> getPlayers(){
		return this.players;
	}
	//returns the number of players in the game
	public int getNumPlayers() {
		return numPlayers;
	}
	//return the name of the game
	public String getGameName() {
		return gameName;
	}
	
	//check to see if game is full
	public Boolean gameFull() {
		if(numPlayers-players.size() == 0) {
			return true;
		}
		else
			return false;
	}
	
	//check to see how many players are left to join 
	public String getPlayersLeft() {
		int left = numPlayers-players.size();
		String remaining = ((Integer)left).toString();
		return remaining;
	}

}
