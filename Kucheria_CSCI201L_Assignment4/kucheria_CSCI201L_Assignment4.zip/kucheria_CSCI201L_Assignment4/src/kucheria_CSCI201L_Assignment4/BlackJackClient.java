package kucheria_CSCI201L_Assignment4;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.InputMismatchException;
import java.util.Scanner;

public class BlackJackClient extends Thread{
	//creating all private variables
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	private String username = null;
	
	public String getUsername() { //getter for username
		return username;
	}
	
	public void setUsername(String username) { //setter for username
		this.username = username;
	}
	
	public BlackJackClient(String host, int port) throws IOException { //constructor
		Socket s = new Socket(host, port);
		oos = new ObjectOutputStream(s.getOutputStream());
		ois = new ObjectInputStream(s.getInputStream());
		Scanner scan = new Scanner(System.in);
		this.start(); //starting run method
	}
	
	public void run() {
		//do receiving of messages from PlayerThread output stream here
		//do sending of responses to PlayerThread input stream here, depending on type of GM
		try {
		while(true) {
			
				GameMessage gm = (GameMessage) ois.readObject(); 
				System.out.println(gm.getMessage());

				if(gm.getType()==1) { //if message requires a response, it is of type 1
					Scanner scan = new Scanner(System.in);
					String answer = scan.nextLine();
					try {
						oos.writeObject(new GameMessage(username,answer, 2));
						oos.flush();
					}
					catch(IOException ioe) {
						System.out.println("exception: " + ioe.getMessage());
					}
				}
				if(gm.getType() == 5) { //if game is over, message of type 5 will be sent, 
					break; //break out of while loop and finish run method
				}
			}
		}
		catch(IOException ioe) { // catching execeptions
			System.out.println("exception: " + ioe.getMessage());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String [] args) { //main method
		System.out.println("Welcome to Black Jack!");
		Boolean allValid = false;
		int port = 0;
		String host = " ";
		while(true) { // keep looping until both a correct ipaddress and port number have been entered
			try {
				Scanner scan = new Scanner(System.in);
				System.out.println("Please enter the ipaddress");
				host = scan.nextLine();
				System.out.println("Please enter the port");
				port = scan.nextInt();
				BlackJackClient cc = new BlackJackClient(host, port);
				break; //if no exception has been thrown, break out of loop
			}
			catch(IOException ioe) {
				System.out.println("Unable to connect to the server with provided fields");
			}
			catch (InputMismatchException ime) {
				System.out.println("Unable to connect to the server with the provided fields");
			}
		}
	}
	
	
}
