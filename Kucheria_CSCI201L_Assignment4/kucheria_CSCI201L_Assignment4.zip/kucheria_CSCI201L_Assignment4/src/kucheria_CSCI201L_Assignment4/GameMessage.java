package kucheria_CSCI201L_Assignment4;

import java.io.Serializable;

public class GameMessage implements Serializable{
	public static final long serialVersionUID = 1;

	//declaring all private data members 
	private String username; 
	private String message;
	private int type;
	
	public String getUsername() { //gets the username of the message
		return username;
	}

	public void setUsername(String username) { //sets the username of the message
		this.username = username; 
	}

	public String getMessage() { //return the message string of the gameMessage
		return message;
	}

	public void setMessage(String message) { //sets the message string that will be sent
		this.message = message;
	}

	
	public int getType() { //return the type of the message
		return this.type;
	}
	
	/*
	 * type is for what kind of messages are being sent
	 * 1 is prompt to player  3 is for game action  5 is for quit game
	 */
	public void setType(int type) {
		this.type = type;
	}
	
	//constructor. takes all 3 components of a message and creates the message object from them
	public GameMessage(String username, String message, int type) {
		this.username = username;
		this.message = message;
		this.type = type;
	}
}
