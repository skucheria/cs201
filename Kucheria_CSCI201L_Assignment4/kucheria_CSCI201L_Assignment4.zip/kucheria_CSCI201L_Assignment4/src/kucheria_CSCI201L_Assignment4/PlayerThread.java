package kucheria_CSCI201L_Assignment4;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

import Game_Tools.Card;

public class PlayerThread extends Thread{
	private ObjectInputStream ois;
	public ObjectOutputStream getOos() { //getting for oos
		return oos;
	}
 
	public int getChips() { //returns number of chips for player
		return chips;
	}

	public void addChips(int val) { //adds val to current chip balance for a player
		chips += val;
	}
	
	public void loseChips(int val) { //subtracts val to current chip balance for a player
		chips -= val;
	}

	//initializing all private data members
	private ObjectOutputStream oos;
	private BlackJackServer server;
	private String username;
	private int chips;
	private Boolean turn = false;
	private Boolean starter = false;
	private ArrayList<Card> hand;
	private int bet;
	private int handValue;
	
	public int getBet() { //return the bet value of the palyer
		return bet;
	}
	
	public void setBet(int x) { //sets the best value of the player
		bet = x;
	}
	
	public ArrayList<Card> getHand(){ //returns the hand of the player
		return hand;
	}
	
	//goes through the hand and calculates the hand value of the player and returns this as a string
	public String getHandValue(ArrayList<Card> hand) { 
		int value = 0;
		String status = "";
		for(Card cards: hand) { //go through cards and get status
			if(cards.getValue()==11 || cards.getValue()==12 || cards.getValue()==13) { //have a face value card
				value+=10;
			}
			else if(cards.getValue() == 14) { //have an ace
				value += 11;
				if(value > 21) { //if busts, then only have one option --> subtract 10
					value -= 10;
				}
			}
			else { //just a regular card
				value += cards.getValue();
			}
		}
		status += value;
		return status;
	}
	
	
	public String getUsername() { //returns the username of the player
		return this.username;
	}
	
	public void setUsername(String username) { //sets the username of the player
		this.username = username;
	}
	
	//constructor initializes the hand and chip values, output and input streams, and starts the run method
	public PlayerThread(Socket s, BlackJackServer server) {
		hand = new ArrayList<Card>();
		chips = 500;
		try {
			ois = new ObjectInputStream(s.getInputStream());
			oos = new ObjectOutputStream(s.getOutputStream());
			this.server = server;
			this.start();
		}
		catch(IOException ioe) {
			System.out.println("exception: " + ioe.getMessage());
		}
	}
	
	//receiving info from Client and sending messages back to Client
	public void run() {
		try {
				GameMessage gm;
				String gameName;
				String numPlayers;
				String gameChoice;
				while(true) { //loop until valid option chosen
					oos.writeObject(new GameMessage("serv", "Please choose from the options below \n" + "1) Start Game \n" + "2) Join Game", 1));
					oos.flush();
					gm = (GameMessage) ois.readObject(); 
					gameChoice = gm.getMessage();
					if( gameChoice.equals("1") ||  gameChoice.equals("2") ) {
						break;
					}else {
						oos.writeObject(new GameMessage("serv", "Invalid choice. Please chooce either option 1 or 2", 3));
						oos.flush();	}
				}
				if(gameChoice.equals("1")) { //creating a game
					while(true) { //for # players
						oos.writeObject(new GameMessage("serv", "Please choose the number of players in the game (1-3)", 1));
						oos.flush();
						gm = (GameMessage) ois.readObject();
						numPlayers = gm.getMessage();
						int num = Integer.valueOf(numPlayers);
						if(num<1 || num>3) { //if invalid input
							oos.writeObject(new GameMessage("serv", "Invalid choice. Not a valid number of players", 3));
							oos.flush();
						}else {
							break;}
					}
					while(true) { //for game name
						oos.writeObject(new GameMessage("serv", "Please choose a name for your game", 1));
						oos.flush();
						gm = (GameMessage) ois.readObject();
						gameName = gm.getMessage();
						Boolean exists = server.roomExists(gameName);
						if(exists==true) {
							oos.writeObject(new GameMessage("serv", "Invalid choice. This name has already been chosen by another player", 3));
							oos.flush();
						}else {
							break;}
					}
					while(true) { //for username
						oos.writeObject(new GameMessage("serv", "Please choose a username", 1));
						oos.flush();
						gm = (GameMessage) ois.readObject();
						username = gm.getMessage();
						Boolean exists = server.currentUser(gameName, username);
						if(exists==true) {
							oos.writeObject(new GameMessage("serv", "Invalid choice. This username has already been chosen by another player in this game", 3));
							oos.flush();
						}else {
							break;}
					}
					this.makeGame(gameName, Integer.valueOf(numPlayers));//create a game here
				}
				else if(gameChoice.equals("2")) { //want to join a game
					while(true) { //for game name
						oos.writeObject(new GameMessage("serv", "Enter the name of the game you wish to join", 1));
						oos.flush();
						gm = (GameMessage) ois.readObject();
						gameName = gm.getMessage();
						Boolean exists = server.roomExists(gameName);
						Boolean full = server.isRoomFull(gameName);
						if(exists==false) {
							oos.writeObject(new GameMessage("serv", "Invalid choice. There are no ongoing games with this name", 3));
							oos.flush();
						}
						else if(full == true) {
							oos.writeObject(new GameMessage("serv", "Invalid choice. Game room is already full", 3));
							oos.flush();
						}else {
							break;}
					}
					while(true) { //for username
						oos.writeObject(new GameMessage("serv", "Please choose a username", 1));
						oos.flush();
						gm = (GameMessage) ois.readObject();
						username = gm.getMessage();
						Boolean exists = server.currentUser(gameName, username);
						if(exists==true) {
							oos.writeObject(new GameMessage("serv", "Invalid choice. This username has already been chosen by another player in this game", 3));
							oos.flush();
						}else {
							break;}
					}
					joinGame(gameName); //join the game after all fields entered have been validated
				}
			}
			catch(IOException ioe) {
				System.out.println("exception: " + ioe.getMessage());
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
	}
	
	//function for a player to join a game of name parameter
	public void joinGame(String name) {
		server.joinGame(name, this);
		BlackJackRoom game = server.getGame(name);
		ArrayList<PlayerThread> players = game.getPlayers();
		
		for(PlayerThread player : players) {
			if(player.starter == true) {
				String mssge = username + " joined the game";
				try {
					player.oos.writeObject(new GameMessage("serv", mssge, 3));
					player.oos.flush();	
					if(game.getPlayers().size()==game.getNumPlayers()) { //enough players in the game
						server.broadcast(name);
					}
					else {
						String left = game.getPlayersLeft();
						player.oos.writeObject(new GameMessage("serv", "Waiting for " + left + " others to join...", 3));
						oos.writeObject(new GameMessage("serv", "The game will start shortly. Waiting for other players to join...", 3));
						oos.flush();
						player.oos.flush();
					}
				}
				catch(IOException ioe) {
					System.out.println("Exception: " +ioe.getMessage());
				}
			}
		}
		
		while(game.getPlayers().size()<game.getNumPlayers()) {} //wait for all players to join
		//start game		
		startGame(game);
	}
	
	public void makeGame(String name, int players) {
		this.starter = true;
		server.createGame(name, players, this);//create a game 
		BlackJackRoom game = server.getGame(name);
		
		if(players == 1) { //single player. can start game
			try {
				oos.writeObject(new GameMessage("serv", "Let the game commence. Good luck to all players!", 3));
				oos.flush();
			}
			catch(IOException ioe) {
				System.out.println("Exception: " +ioe.getMessage());
			}
			startGame(game);
		}
		else {
			try {
				String left = game.getPlayersLeft();
				oos.writeObject(new GameMessage("serv", "Waiting for " + left + " others to join...", 3));
				oos.flush();
			}
			catch(IOException ioe) {
				System.out.println("Exception: " +ioe.getMessage());
			}
			while(game.getPlayers().size()<players) {} //wait for all players to join
		}		
	}
	
	public void startGame(BlackJackRoom game) {
		ArrayList<PlayerThread> players = game.getPlayers();
		int round = 0;
		Boolean isOver = false;
		while(isOver == false) { //all gameplay is done in this while loop while all players have at least 1 chip
			round++;
			for(PlayerThread player : players) {
				try {
					player.oos.writeObject(new GameMessage("serv", "ROUND " + round + "\n" + "Dealer is shuffling cards...", 3));
					player.oos.flush();
				}
				catch(IOException ioe) {
					System.out.println("Exception: " +ioe.getMessage());
				}
			}
			game.shuffle(); //shuffling deck		
			game.deal(); //deal first set of cards;
			game.deal(); //deal second set of cards;
			
			for(PlayerThread player: players) { //going through all players and placing bets
				player.makeBets(game, player);
			}
			printInitialState(players, game);
			for(PlayerThread player: players) { //going through all players and doing hit or stay
				hitOrStay(game, player);
			}
			playForDealer(game);
			for(PlayerThread player: players) { //go thru all players and print out totals to their console
				showChipTotals(game, player);
			}
			prepareForNewRound(game); //clear hands and get new deck
			
			for(PlayerThread player : players) { //check to see if game is over by going through chip values
				if(player.getChips() == 0) {
					isOver = true;
				}
			}
		}
		endGame(game);
	}
	//end game by printing out whether the person is a winner(>0 chipps) or lose (<0 chips)
	public void endGame(BlackJackRoom game) {
		for(PlayerThread player : game.getPlayers()) {
			if(player.getChips() > 0) { //if they are a winner 
				try {
					player.oos.writeObject(new GameMessage("serv", "You have" + player.getChips() + " chips!", 5));
					player.oos.flush();
				}
				catch(IOException ioe) {
					System.out.println("Exception: " +ioe.getMessage());
				}
			}
			else { //if they are a loser
				try {
					player.oos.writeObject(new GameMessage("serv", "You lost!", 5));
					player.oos.flush();
				}
				catch(IOException ioe) {
					System.out.println("Exception: " +ioe.getMessage());
				}
			}
		}
	}
	
	//clear all players hands and get a full deck
	public void prepareForNewRound(BlackJackRoom game) { 
		game.clearAllHands();
		game.getNewDeck();
	}
	
	//first get the dealer hand status
	//go through all the players and see what their hand status is. if blackjack, double chips. if bust, lose chips, if neither of those, compare to dealers
	public void showChipTotals(BlackJackRoom game, PlayerThread player) {
		ArrayList<Card> dealerHand = game.getDealerHand();
		String dealerStatus = getHandValue(dealerHand);
		String message = "";
		String youMessage = "";
		Boolean toPerson = false;
			String playerStatus = getHandValue(player.getHand());
			if(Integer.valueOf(dealerStatus) < 21) { //if dealer isnt bust
				if(Integer.valueOf(playerStatus) < Integer.valueOf(dealerStatus)) { //player hand less than dealer hand 
					player.loseChips(player.getBet()); //deduct chips from persons total
					toPerson = true;
					youMessage += "You had a sum less than the dealer. " +  player.getBet() + " chips were deducted to your total." ;
					message += player.getUsername() + " had a sum less than the dealer. " +  player.getBet() + " chips were deducted from " + player.getUsername()+ "'s total." ;
				}
				else if(Integer.valueOf(playerStatus) == Integer.valueOf(dealerStatus)) { //player hand equal to dealer hand. no chips gain/loss
						toPerson = true;
						youMessage += "You tied with the dealer. Your chip total remains the same." ; 
						message += player.getUsername() + " tied with the dealer. " +  player.getBet() + "'s chip total remains the same" ;
				}
				else if(Integer.valueOf(playerStatus) > Integer.valueOf(dealerStatus) && Integer.valueOf(playerStatus) < 21) { //dont have blackjack/bust so need to compare to dealer
					player.addChips(player.getBet()); //add chips to persons total
						youMessage += "You had a sum greater than the dealer. " +  player.getBet() + " chips were added to your total." ; 
						message += player.getUsername() + " had a sum greater than the dealer." +  player.getBet() + " chips were added to "+ player.getUsername()+ "'s total.";
				}
				else if(Integer.valueOf(playerStatus) == 21) { //if they have blackjack
					int total = 2*player.getBet();
					player.addChips(total); //add double chips to persons total
						toPerson = true;
						youMessage += "You had blackjack. " + total + " chips were added to your total." ; 
						message += player.getUsername() + " had blackjack. " +  total + " chips were added to "+ player.getUsername()+ "'s total.";
				}
				else if(Integer.valueOf(playerStatus) > 21) { //if they busted
					player.loseChips(player.getBet()); //deduct chips from persons total
					
						toPerson = true;
						youMessage += "You busted. " +  player.getBet() + " chips were deducted from your total." ; 
						message += player.getUsername() + " busted. " +  player.getBet() + " chips were deducted from " + player.getUsername()+ "'s total." ;
				}
			}
			//////////////////////////////////////////////////
			else if(Integer.valueOf(dealerStatus) == 21) { //if dealer got blackjack
				if(Integer.valueOf(playerStatus) == Integer.valueOf(dealerStatus)) { //player has blackjack
					youMessage += "You tied with the dealer. Your chip total remains the same." ;
					message += player.getUsername() + " tied with the dealer. " + player.getBet() + "'s chip total remains the same" ;
				}
				else if(Integer.valueOf(playerStatus) < Integer.valueOf(dealerStatus)) { //player hand less than dealer hand 
					player.loseChips(player.getBet()); //deduct chips from persons total
					youMessage += "You had a sum less than the dealer. " +  player.getBet() + " chips were deducted to your total." ;
					message += player.getUsername() + " had a sum less than the dealer. " +  player.getBet() + " chips were deducted from " + player.getUsername()+ "'s total." ;
				}
				else if(Integer.valueOf(playerStatus) > 21) { //if they busted
					player.loseChips(player.getBet()); //deduct chips from persons total
					youMessage += "You busted. " +  player.getBet() + " chips were deducted from your total." ;
					message += player.getUsername() + " busted. " +  player.getBet() + " chips were deducted from " + player.getUsername()+ "'s total." ;
				}
			}
			//////////////////////////////////////////////////
			else if(Integer.valueOf(dealerStatus) > 21) { //if dealer bust
				if(player.getUsername().equals(player.getUsername())) {
					player.loseChips(player.getBet()); //deduct chips from persons total
					youMessage += "You busted. " + player.getBet() + " chips were deducted from your total" ;
					message += player.getUsername() + " busted. " +  player.getBet() + " chips were deducted from " + player.getUsername()+ "'s total." ;
				}
				
				else if(Integer.valueOf(playerStatus) == 21) { //if they have blackjack
					int total = 2*player.getBet();
					player.addChips(total); //add double chips to persons total
					youMessage += "You had blackjack. " + total + " chips were added to your total. " ;
					message += player.getUsername() + " had blackjack. " +  total + " chips were added to "+ player.getUsername()+ "'s total.";
				}
				else if(Integer.valueOf(playerStatus) > 21) { //if they busted
					player.loseChips(player.getBet()); //deduct chips from persons total
					youMessage += "You busted. " + player.getBet() + " chips were deducted from your total" ;
					message += player.getUsername() + " busted. " +  player.getBet() + " chips were deducted from " + player.getUsername()+ "'s total." ;
				}
				else if(Integer.valueOf(playerStatus) < 21) { //if they busted
					player.addChips(player.getBet()); //deduct chips from persons total
					youMessage += "You had a value less than the dealer. " + player.getBet() + " chips were added to your total" ;		
					message += player.getUsername() + " had a value less than the dealer. " +  player.getBet() + " chips were added to " + player.getUsername()+ "'s total." ;
				}
			}			
			message += "\n";
		//now send out to that specific player
		for(PlayerThread person: game.getPlayers()) {
			try {
				if(person.getUsername().equals(player.getUsername())) { // print as "you"
					person.oos.writeObject(new GameMessage("serv", youMessage, 3));
					person.oos.flush();
				}
				else { //print as username
					person.oos.writeObject(new GameMessage("serv", message, 3));
					person.oos.flush();
				}
			}
			catch(IOException ioe) {
				System.out.println("Exception: " +ioe.getMessage());
			}
		}
	}
	
	//playing for dealer in this function by hitting until they are at least 17
	public void playForDealer(BlackJackRoom game) {
		for(PlayerThread player : game.getPlayers()) { //send initial string out to everyone
			try {
				player.oos.writeObject(new GameMessage("serv", "It is now time for the dealer to play.", 3));
				player.oos.flush();
			}
			catch(IOException ioe) {
				System.out.println("Exception: " +ioe.getMessage());
			}
		}
		int numHits = 0;
		ArrayList<Card> dealerHand = game.getDealerHand();
		String currValue = getHandValue(game.getDealerHand());
		while(Integer.valueOf(currValue) < 17){
			game.dealForDealer();
			currValue = getHandValue(game.getDealerHand());
			numHits++;
			String hits = "The dealer hit 1 time.";
			if(numHits > 1)
				hits = "The dealer hit another time.";
			for(PlayerThread player : game.getPlayers()) { //send initial string out to everyone
				try {
					player.oos.writeObject(new GameMessage("serv", hits + " They were dealt the " + dealerHand.get(dealerHand.size()-1).getName(), 3));
					player.oos.flush();
				}
				catch(IOException ioe) {
					System.out.println("Exception: " +ioe.getMessage());
				}
			}
		}
		sendSinglePlayerStatus(game.getPlayers(), "DEALER", null, game.getDealerHand());
		
	}
	
	//main function to display the hitting/staying prompts and go through getting values and checking to see if they've busted or not
	public void hitOrStay(BlackJackRoom game, PlayerThread player) {
		Boolean notStay = true;
		String prompt = "Enter either '1' or 'stay' to stay. Enter either '2' or 'hit' to hit.";
		String toOthers = "It is " + player.getUsername() + "'s turn to add cards to their hand";
		sendHitInfo(game.getPlayers(), player, toOthers); //send hit/stay turn to other players
		try {
			player.oos.writeObject(new GameMessage("serv","It is your turn to add cards to your hand", 3));
			player.oos.flush();
		}
		catch(IOException ioe) {
			System.out.println("Exception");
		}
		try {
			while(true) {
				player.oos.writeObject(new GameMessage("serv",prompt, 1));
				player.oos.flush();
				GameMessage gm = (GameMessage) player.ois.readObject();
				String decision = gm.getMessage();
				if(decision.equals("1") || decision.equals("stay")) { //if player chooses stay
					player.oos.writeObject(new GameMessage("serv","You stayed", 3));
					player.oos.flush();
					sendHitInfo(game.getPlayers(), player, player.getUsername() + " stayed");
					sendSinglePlayerStatus(game.getPlayers(), player.getUsername(), player, player.getHand());
					break;
				}
				else if(decision.equals("2") || decision.equals("hit")) { //deal a card. check value. if under let them hit again. if bust, then print out losing message and break
					game.dealSinglePlayer(player); //dealing card for single player
					player.oos.writeObject(new GameMessage("serv","You hit. You were dealt the " + player.getHand().get(player.getHand().size()-1).getName(), 3));
					player.oos.flush();
					String mssge = player.getUsername() + " hit. They were dealt the " + player.getHand().get(player.getHand().size()-1).getName();
					sendHitInfo(game.getPlayers(), player, mssge);
					int value = Integer.valueOf(player.getHandValue(player.getHand()));
					if(value > 21) {
						mssge = player.getUsername() + " busted! They lose " + player.getBet() + " chips";
						sendHitInfo(game.getPlayers(), player, mssge);
						sendSinglePlayerStatus(game.getPlayers(), player.getUsername(), player, player.getHand());
						break;
					}
				}
				else { //invalid choice entered
					player.oos.writeObject(new GameMessage("serv", "Invalid choice.", 3));
					player.oos.flush();
				}
			}
		}
		catch(IOException ioe) {
			System.out.println("Exception: " +ioe.getMessage());
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}	
		
	}
	
	//this is to show the status of players after betting 
	public void sendSinglePlayerStatus(ArrayList<PlayerThread> players, String username, PlayerThread plyr, ArrayList<Card> hand) {
		String handStatus = getHandValue(hand);
		if(Integer.valueOf(handStatus) > 21) 
			handStatus += " - bust";
		else if(Integer.valueOf(handStatus) == 21) 
			handStatus += " - blackjack";

		String toSend = "";
		if(username.equals("DEALER")) //creating a different string if its a dealer
			toSend = "----------------------------------------------------------" + "\n" + (username + "\n" + "\n") + "Status: " + handStatus + "\n";
		else
			toSend = "----------------------------------------------------------" + "\n" + "Player: " + (username + "\n" + "\n") + "Status: " + handStatus + "\n";
		for(Card card : hand) {
			toSend += "| " + card.getName() + " |";
		}
		if(!username.equals("DEALER")) 
			toSend += "\n" + "Chip Total: " + plyr.getChips() + " | Bet Amount: " + plyr.getBet() + "\n" + "----------------------------------------------------------" + "\n";
		else {
			toSend += "\n" + "----------------------------------------------------------" + "\n";
		}
		for(PlayerThread player : players) { //looping through all players and sending out everyone's hands
			try {
				player.oos.writeObject(new GameMessage("serv", toSend, 3));
				player.oos.flush();
			}
			catch(IOException ioe) {
				System.out.println("Exception: " +ioe.getMessage());
			}
		}
	}
	
	//sends to all players except playing what whether playing hit or stay 
	public void sendHitInfo(ArrayList<PlayerThread> players, PlayerThread playing, String message) {
		for(PlayerThread player : players) {
			if(!player.getUsername().equals(playing.getUsername())) {
				try {
					player.oos.writeObject(new GameMessage("serv", message, 3));
					player.oos.flush();
				}
				catch(IOException ioe) {
					System.out.println("Exception: " +ioe.getMessage());
				}
			}
		}
	}
	
	//sends the messages to current better and other players about whose turn it is and what they bet
	public void makeBets(BlackJackRoom game, PlayerThread player) {
		ArrayList<PlayerThread> players = game.getPlayers();
		String msg = player.getUsername() + ", it is your turn to make a bet. Your chip total is " + chips;
		sendCurrentBetterToOthers(players, player); //send who's turn it is to bet to other players
		try {
			player.oos.writeObject(new GameMessage("serv", msg, 1)); //send message to player who's turn it is to bet
			player.oos.flush();
			GameMessage gm = (GameMessage) player.ois.readObject();
			player.setBet(Integer.valueOf(gm.getMessage()));
			int tempBet = this.bet;
			player.oos.writeObject(new GameMessage("serv", "You bet " + bet + " chips", 3));
			player.oos.flush();
			sendBetValueToOthers(players, player, tempBet);
		}
		catch(IOException ioe) {
			System.out.println("Exception: " +ioe.getMessage());
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}	
	}
	//prints the initial state of the game with the hands of the dealer and all the players
	public void printInitialState(ArrayList<PlayerThread> players, BlackJackRoom game) {
		ArrayList<Card> dealerHand = game.getDealerHand();
		sendHand(dealerHand, players, "DEALER", null);
		for(PlayerThread player : players) {
			sendHand(player.getHand(), players, player.getUsername(), player);
		}
	}
	
	//prints the hand of plyr to all players in the game
	public void sendHand(ArrayList<Card> hand, ArrayList<PlayerThread> players, String username, PlayerThread plyr) {
		String sendingString = "";
		if(username.equals("DEALER")) { //making status string for dealer
			String sendIt = "----------------------------------------------------------" + "\n" + (username + "\n" + "\n");
			sendIt += "Cards: | ? | " ;
			for(int x=1; x<hand.size(); x++) {
				sendIt += "| " + hand.get(x).getName() + " |";
			}
			sendIt += "\n" + "----------------------------------------------------------" + "\n";
			sendingString += sendIt;
		}
		else { //not a dealer for preparing the string
			String sendIt = "----------------------------------------------------------" + "\n" + "Player: " + username + "\n" + "\n";
			String status = getHandValue(hand);
			sendIt += "Status: " + status + "\n" + "Cards: ";
			for(Card card : hand) {
				sendIt += "| " + card.getName() + " |";
			}
			sendIt += "\n" + "Chip Total: " + plyr.getChips() + " | Bet Amount: " + plyr.getBet() + "\n";
			sendIt += "----------------------------------------------------------" + "\n";
			sendingString += sendIt;
		}
		
		for(PlayerThread player:players) { //loop through all players and send out sendIt string to them
			try {
				player.oos.writeObject(new GameMessage("serv", sendingString, 3));
				player.oos.flush();
			}
			catch(IOException ioe) {
				System.out.println("Exception: " +ioe.getMessage());
			}
		}
	}
	
	//function sends the amount the current better bet to all other players 
	public void sendBetValueToOthers(ArrayList<PlayerThread> players, PlayerThread playing, int aBet) {
		for(PlayerThread player : players) {
			if(!player.getUsername().equals(playing.getUsername())) {
				try {
					player.oos.writeObject(new GameMessage("serv", playing.getUsername() + " bet " + aBet + " chips", 3));
					player.oos.flush();
				}
				catch(IOException ioe) {
					System.out.println("Exception: " +ioe.getMessage());
				}
			}
		}
	}
	//function sends the name of the player whose turn it is to bet to all other players
	public void sendCurrentBetterToOthers(ArrayList<PlayerThread> players, PlayerThread playing) {
		for(PlayerThread player : players) {
			if(!player.getUsername().equals(playing.getUsername())) {
				try {
					player.oos.writeObject(new GameMessage("serv", "It is " + playing.getUsername() + "'s turn to make a bet", 3));
					player.oos.flush();
				}
				catch(IOException ioe) {
					System.out.println("Exception: " +ioe.getMessage());
				}
			}
		}
	}
	
}
