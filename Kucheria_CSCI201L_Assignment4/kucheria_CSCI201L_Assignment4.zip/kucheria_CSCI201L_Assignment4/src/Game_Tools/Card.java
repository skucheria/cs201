package Game_Tools;

public class Card {
	private String name;
	private String suit;
	private int value;
	
	public Card(String suit, int value) {
		this.suit = suit;
		this.value = value;
		if(value == 11) //checking for jack, queen, king, and ace
			this.name = "JACK of " + suit;
		else if(value == 12) 
			this.name = "QUEEN of " + suit;
		else if(value == 13) 
			this.name = "KING of " + suit;
		else if(value == 14) 
			this.name = "ACE of " + suit;
		else
			this.name = value + " of " + suit;
	}
	
	public String getSuit() { //getter for suit
		return this.suit;
	}
	
	public int getValue() { //getter for value
		return this.value;
	}
	
	public String getName() { //getter for name combining suit and value
		return this.name;
	}
}
