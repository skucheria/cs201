package Game_Tools;

import java.util.ArrayList;
import java.util.Collections;

public class Deck {
	private ArrayList<Card> deck;
	
	public Deck() {
		ArrayList<String> suits = new ArrayList<String>(); //making list of suits
		deck = new ArrayList<Card>();
		suits.add("HEARTS");
		suits.add("SPADES");
		suits.add("CLUBS");
		suits.add("DIAMONDS");
		
		for(int x=0; x<4; x++) { //going through suits
			for(int y=2; y<15; y++) { //going through numbers
				deck.add(new Card(suits.get(x), y)); //filling out deck with all cards
			}
		}
	}
	
	public void shuffle() { //shuffling deck 10x using collections
		for(int x=0; x<10; x++) {
			Collections.shuffle(deck);
		}
	}
	
	public ArrayList<Card> getDeck() { //getter for returning the deck
		return this.deck;
	}
	
	public Card deal() { //function to deal out a single card. takes off top card and returns it
		Card returnCard = deck.get(0);
		deck.remove(0);
		return returnCard;
	}
}
