package kucheria_CSCI201L_Assignment2_Classes;

public class Name {
	private String fname;
	private String lname;

	public String getFname() {
		return fname;
	}
	public String getLname() {
		return lname;
	}
	
	

}
