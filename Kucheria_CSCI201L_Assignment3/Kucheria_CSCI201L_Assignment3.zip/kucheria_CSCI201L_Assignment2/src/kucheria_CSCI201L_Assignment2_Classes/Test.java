package kucheria_CSCI201L_Assignment2_Classes;

import java.util.ArrayList;

public class Test {
	private String title;
	public String getTitle() {
		return title;
	}
	public ArrayList<Files> getFiles() {
		return files;
	}
	private ArrayList<Files> files;
	

}
