package kucheria_CSCI201L_Assignment2_Classes;

import java.util.ArrayList;

public class School {
	public String getName() {
		return name;
	}
	
	private String name;
	private ArrayList<Department> departments;
	
	
	public ArrayList<Department> getDepartments() {
		return departments;
	}

	public String getImage() {
		return image;
	}

	String image;
	

	public School() {
        this.departments = new ArrayList<Department>();
	}
	
	
	
}
