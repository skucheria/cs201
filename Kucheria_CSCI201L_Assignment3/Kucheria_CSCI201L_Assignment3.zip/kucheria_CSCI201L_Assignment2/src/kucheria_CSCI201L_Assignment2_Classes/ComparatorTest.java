package kucheria_CSCI201L_Assignment2_Classes;

import java.util.ArrayList;
import java.util.Collections;

public class ComparatorTest {
    public static void main(String args[]) {
        ArrayList<Assignment> asses = new ArrayList<Assignment>();
        asses.add(new Assignment("9-12-2017"));
        asses.add(new Assignment("8-27-2017"));
        asses.add(new Assignment("8-17-2017"));


        System.out.println("Order of students before sorting is: ");
        
        for(Assignment a : asses) {
        		System.out.println(a.getDueDate());
        }

        Collections.sort(asses, new AssignmentDueDateComparator());
        
		System.out.println("Order of students after sorting by student name is");

		 for(Assignment a : asses) {
     		System.out.println(a.getDueDate());
		 }
		
	

    }
}
