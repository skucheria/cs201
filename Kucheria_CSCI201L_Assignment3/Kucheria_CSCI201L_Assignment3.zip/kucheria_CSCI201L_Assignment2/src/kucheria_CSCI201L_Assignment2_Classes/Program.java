package kucheria_CSCI201L_Assignment2_Classes;

import java.util.ArrayList;

public class Program {
	public ArrayList<Files> getFiles() {
		return files;
	}

	private ArrayList<Files> files;
	
}
