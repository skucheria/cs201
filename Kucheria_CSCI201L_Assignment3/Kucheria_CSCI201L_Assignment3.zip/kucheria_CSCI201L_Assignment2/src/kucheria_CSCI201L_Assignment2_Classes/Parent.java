package kucheria_CSCI201L_Assignment2_Classes;

import java.util.ArrayList;

public class Parent {
	private ArrayList<School> schools;
	
	

	public Parent() {
		schools = new ArrayList<School>();
	}
	
	public ArrayList<School> getSchools() {
		return schools;
	}
}
