package kucheria_CSCI201L_Assignment2_Classes;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;

public  class AssignmentDueDateComparator implements Comparator<Assignment> {
	@Override
	public int compare(Assignment a1, Assignment a2) {
		String due1 = a1.getDueDate();
		String due2 = a2.getDueDate();
	
		String comp1 = "";
 		String comp2 = "";
 	
 		comp1 += due1.substring(0,due1.indexOf("-"));
 		comp1 += due1.substring(due1.indexOf("-")+1, due1.lastIndexOf("-"));
 		comp1 += due1.substring(due1.lastIndexOf("-")+1, due1.length());
 		
 		comp2 += due2.substring(0,due2.indexOf("-"));
 		comp2 += due2.substring(due2.indexOf("-")+1, due2.lastIndexOf("-"));
 		comp2 += due2.substring(due2.lastIndexOf("-")+1, due2.length());
        
 		return (Integer.valueOf(comp1).compareTo(Integer.valueOf(comp2)));
	}
}
