package kucheria_CSCI201L_Assignment2_Classes;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;

public class AssignmentAssignedDateComparator implements Comparator<Assignment> {
	@Override
	public int compare(Assignment a1, Assignment a2) {
        SimpleDateFormat format = new SimpleDateFormat("mm-dd-yyyy");
        try {
			return format.parse(a1.getAssignedDate()).compareTo(format.parse(a2.getAssignedDate()));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return 0; 
	}
}
