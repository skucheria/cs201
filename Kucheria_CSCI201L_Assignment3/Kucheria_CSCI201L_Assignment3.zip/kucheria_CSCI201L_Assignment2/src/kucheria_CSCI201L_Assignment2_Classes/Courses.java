package kucheria_CSCI201L_Assignment2_Classes;

import java.util.ArrayList;

public class Courses {
	private String number;
	private String term;
	private int year;
	private ArrayList<Staff> staffMembers;
	private ArrayList<Meeting> meetings;
	private ArrayList<Exams> exams;
	
	public ArrayList<Exams> getExams() {
		return exams;
	}
	public ArrayList<Assignment> getAssignments() {
		return assignments;
	}

	private ArrayList<Assignment> assignments;

	String title;
	public Schedule getSchedule() {
		return schedule;
	}

	

	private Schedule schedule;
	
	public Syllabus getSyllabus() {
		return syllabus;
	}

	public void setSyllabus(Syllabus syllabus) {
		this.syllabus = syllabus;
	}

	private Syllabus syllabus;
	
	public String getTitle() {
		return title;
	}

	public int getUnits() {
		return units;
	}

	int units;

	public String getNum() {
		return number;
	}
	public String getTerm() {
		return term;
	}
	public int getYear() {
		return year;
	}
	public ArrayList<Staff> getStaff() {
		return staffMembers;
	}
	
	public ArrayList<Meeting> getMeetings() {
		return meetings;
	}
	
	

}
