package kucheria_CSCI201L_Assignment2_Classes;

import java.util.ArrayList;

public class Week {
	private int week;
	public int getWeek() {
		return week;
	}
	public ArrayList<Lab> getLabs() {
		return labs;
	}
	public ArrayList<Lecture> getLectures() {
		return lectures;
	}
	private ArrayList<Lab> labs;
	private ArrayList<Lecture> lectures;

}
