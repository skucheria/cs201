package kucheria_CSCI201L_Assignment2_Classes;

public class Assistant {
	public int getStaffMemberID() {
		return staffMemberID;
	}
	// private data members
	private int staffMemberID;
	
	
}
