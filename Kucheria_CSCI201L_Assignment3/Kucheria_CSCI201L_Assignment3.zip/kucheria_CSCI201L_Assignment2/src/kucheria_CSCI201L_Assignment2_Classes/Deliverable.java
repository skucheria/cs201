package kucheria_CSCI201L_Assignment2_Classes;

import java.util.ArrayList;

public class Deliverable {
	private int number;
	public int getNumber() {
		return number;
	}
	public String getDueDate() {
		return dueDate;
	}
	public String getTitle() {
		return title;
	}
	public String getGradePercentage() {
		return gradePercentage;
	}
	public ArrayList<Files> getFiles() {
		return files;
	}
	private String dueDate;
	private String title;
	private String gradePercentage;
	private ArrayList<Files> files;
	
	
}
