package kucheria_CSCI201L_Assignment2_Classes;

public class Files {
	private String number;
	public String getNumber() {
		return number;
	}
	public String getTitle() {
		return title;
	}
	public String getUrl() {
		return url;
	}
	private String title;
	private String url;

	
}
