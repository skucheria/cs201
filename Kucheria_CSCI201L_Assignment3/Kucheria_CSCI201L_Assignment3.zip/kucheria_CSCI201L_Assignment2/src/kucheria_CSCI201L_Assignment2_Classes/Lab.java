package kucheria_CSCI201L_Assignment2_Classes;

public class Lab {
	private int number;
	public int getNumber() {
		return number;
	}
	public String getTitle() {
		return title;
	}
	public String getUrl() {
		return url;
	}
	private String title;
	private String url;
}
