package kucheria_CSCI201L_Assignment2_Classes;

public class Time {
	private String start;
	public String getStart() {
		return start;
	}

	public String getEnd() {
		return end;
	}

	private String end;
	
	public Time(String start, String end) {
		this.start = start;
		this.end = end;
	}
}

