package kucheria_CSCI201L_Assignment2_Classes;

import java.util.ArrayList;

public class Staff {
	private String type; 
	private int id; 
	private Name name;
	private String email;  
	private String image;
	private String phone; 
	private String office; 
	private ArrayList<OfficeHours> officeHours;
	
	public Staff(String type, int id, Name name,  String email, 
			String image, String phone, String office, ArrayList<OfficeHours> oHours ) {
		this.type = type;
		this.id = id;
		this.name = name;
		this.email = email;
		this.image = image;
		this.phone = phone;
		this.office = office;
		this.officeHours = oHours;
	}
	
	public String getType(){
		return type;
	}
	public int getId(){
		return id;
	}
	public Name getName() {
		return name;
	}
	public String getEmail(){
		return email;
	}
	public String getImage(){
		return image;
	}
	public String getPhone(){
		return phone;
	}
	public String getOffice(){
		return office;
	}
	public ArrayList<OfficeHours> getOH(){
		return officeHours;
	}
}
