package kucheria_CSCI201L_Assignment2_Classes;

import java.util.ArrayList;

public class Schedule {
	private ArrayList<Textbook> textbooks;
	public ArrayList<Textbook> getTextbooks() {
		return textbooks;
	}
	public void setTextbooks(ArrayList<Textbook> textbooks) {
		this.textbooks = textbooks;
	}
	public ArrayList<Week> getWeeks() {
		return weeks;
	}
	public void setWeeks(ArrayList<Week> weeks) {
		this.weeks = weeks;
	}
	private ArrayList<Week> weeks;

}
