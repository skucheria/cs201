package kucheria_CSCI201L_Assignment2_Classes;

import java.util.ArrayList;

public class Assignment {
	private String number;
	public String getNumber() {
		return number;
	}
	public String getAssignedDate() {
		return assignedDate;
	}
	public String getTitle() {
		return title;
	}
	public String getUrl() {
		return url;
	}
	public ArrayList<Files> getFiles() { //files getter method
		return files;
	}
	public ArrayList<Files> getGradingCriteriaFiles() {
		return gradingCriteriaFiles;
	}
	public ArrayList<Files> getSolutionFiles() {
		return solutionFiles;
	}
	public ArrayList<Deliverable> getDeliverables() {
		return deliverables;
	}
	public String getGradePercentage() {
		return gradePercentage;
	}
	private String assignedDate;
	public String getDueDate() {
		return dueDate;
	}
	private String dueDate;
//private data members
	private String title;
	private String url;
	private ArrayList<Files> files;
	private ArrayList<Files> gradingCriteriaFiles;
	private ArrayList<Files> solutionFiles;
	private ArrayList<Deliverable> deliverables;
	private String gradePercentage;
}
