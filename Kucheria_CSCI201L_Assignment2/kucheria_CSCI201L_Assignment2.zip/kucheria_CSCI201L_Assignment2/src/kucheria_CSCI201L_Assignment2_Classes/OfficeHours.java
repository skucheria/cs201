package kucheria_CSCI201L_Assignment2_Classes;

public class OfficeHours {
	private String day;
	private Time time;

	
	public OfficeHours(String day, Time t) {
		this.day = day;
		time = t;
	}
	
	public String getDay() {
		return day;
	}
	public Time getTime() {
		return time;
	}
}
