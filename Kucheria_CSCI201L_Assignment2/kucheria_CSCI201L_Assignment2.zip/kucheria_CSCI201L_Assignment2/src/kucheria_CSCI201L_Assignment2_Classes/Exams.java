package kucheria_CSCI201L_Assignment2_Classes;

import java.util.ArrayList;

public class Exams {
	private String semester;
	public String getSemester() {
		return semester;
	}
	public String getYear() {
		return year;
	}
	public ArrayList<Test> getTests() {
		return tests;
	}
	private String year;
	private ArrayList<Test> tests;
	
	
	public Test getTestType(String s){
		Test ret = null;
		for(int x=0; x<tests.size(); x++) {
			if(s.equals(tests.get(x).getTitle()))
				ret = tests.get(x);
		}
		return ret;
	}
	
}
