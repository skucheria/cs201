package kucheria_CSCI201L_Assignment2_Classes;

public class Syllabus {
	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	String url;
	
	
}
