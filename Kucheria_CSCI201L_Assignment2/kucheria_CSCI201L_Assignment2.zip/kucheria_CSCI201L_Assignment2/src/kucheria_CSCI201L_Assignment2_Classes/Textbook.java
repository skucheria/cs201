package kucheria_CSCI201L_Assignment2_Classes;

public class Textbook {
	private int number;
	public int getNumber() {
		return number;
	}
	public int getYear() {
		return year;
	}
	public String getPublisher() {
		return publisher;
	}
	public String getAuthor() {
		return author;
	}
	public String getTitle() {
		return title;
	}
	public String getIsbn() {
		return isbn;
	}
	private int year;
	private String publisher;
	private String author;
	private String title;
	private String isbn;

}
