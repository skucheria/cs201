package kucheria_CSCI201L_Assignment2_Classes;

import java.util.ArrayList;

public class Topics {
	private int number;
	public int getNumber() {
		return number;
	}
	public String getTitle() {
		return title;
	}
	public String getUrl() {
		return url;
	}
	private String title;
	private String url;
	private String chapter;
	public String getChapter() {
		return chapter;
	}
	public ArrayList<Program> getPrograms() {
		return programs;
	}
	private ArrayList<Program> programs;
	
	

}
