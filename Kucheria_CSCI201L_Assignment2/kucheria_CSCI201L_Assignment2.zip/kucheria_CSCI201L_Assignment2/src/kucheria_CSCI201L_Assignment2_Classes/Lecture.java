package kucheria_CSCI201L_Assignment2_Classes;

import java.util.ArrayList;

public class Lecture {
	private String number;
	public String getNumber() {
		return number;
	}
	public String getDate() {
		return date;
	}
	public String getDay() {
		return day;
	}
	public ArrayList<Topics> getTopics() {
		return topics;
	}
	private String date;
	private String day;
	private ArrayList<Topics> topics;
}
